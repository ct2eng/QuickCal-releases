# 刪除與移動事件流程文檔

## 概述

QuickCal 支援三種日曆操作：
1. **CREATE** - 新增事件（原有功能）
2. **DELETE** - 刪除事件（新功能）
3. **MOVE** - 移動事件（新功能）

本文檔詳細說明刪除和移動事件的完整流程。

---

## 整體架構

### 核心組件

1. **MainViewModel** - 主要協調器，處理所有業務邏輯
2. **AIParsingService** - AI 解析服務，判斷使用者意圖
3. **CalendarService** - 日曆服務，執行 EventKit 操作
4. **EventSelectionView** - 事件選擇 UI，讓使用者確認操作

### 資料模型

```swift
// 動作類型
enum CalendarActionType: String {
    case create
    case delete
    case move
}

// 動作解析結果
struct ActionParseResult {
    let type: CalendarActionType
    let targetDate: Date?        // 事件目前所在的日期（來源日期）
    let newDate: Date?            // 移動的目標日期（僅用於 move）
    let originalText: String
    let event: CalendarEventInfo?
    let confidence: Double
}

// 日曆事件資訊
struct CalendarEventInfo {
    let id: String
    let title: String
    let startDate: Date
    let endDate: Date
    let location: String?
    let notes: String?
}
```

---

## 完整流程

### Phase 1: 使用者輸入與動作識別

#### 1.1 使用者輸入
```
使用者輸入範例：
- "刪除明天的會議"
- "取消今天下午的 meeting"
- "移動今天會議到明天"
- "把週五的 meeting 移到下週一"
```

#### 1.2 觸發解析
```swift
// MainViewModel.send()
func send() async {
    // 1. OCR 處理（如果有圖片）
    // 2. 清空 inputText
    // 3. 設定 parsing 狀態
    appState = .parsing
    
    // 4. 呼叫 AI 判斷動作類型
    let actionResult = try await aiService.parseAction(textToParse, context: context)
}
```

#### 1.3 AI 動作分類

**Prompt 結構** (`buildActionPrompt`):
```
Current date: 2026年2月13日 下午7:00
Today's date: 2026-02-13
Timezone: Asia/Taipei (+08:00)

User input: <<<移動今天會議到明天>>>

Determine the user's intent:
- "create": 新增事件
- "delete": 刪除事件
- "move": 移動事件

CRITICAL DATE FORMAT RULES:
- 必須將相對日期轉換為 YYYY-MM-DD 格式
- 如果有時間，使用 ISO8601: "2026-02-14T14:00:00+08:00"

Return JSON:
{
  "type": "move",
  "targetDate": "2026-02-13",  // 事件目前所在日期
  "newDate": "2026-02-14",      // 移動目標日期
  "confidence": 1.0
}
```

**AI 回應範例**:
```json
{
  "type": "move",
  "targetDate": "2026-02-13",
  "newDate": "2026-02-14T14:00:00+08:00",
  "confidence": 1.0
}
```

#### 1.4 解析 AI 回應

```swift
// AIParsingService.parseActionResponse()
func parseActionResponse(_ response: String, originalText: String, context: ParsingContext) throws -> ActionParseResult {
    // 1. 提取 JSON
    let jsonString = extractJSON(from: response)
    
    // 2. 自訂日期解析策略
    decoder.dateDecodingStrategy = .custom { decoder in
        // 支援兩種格式：
        // - ISO8601: "2026-02-14T14:00:00+08:00"
        // - Date-only: "2026-02-13"
    }
    
    // 3. 解析並返回 ActionParseResult
    return ActionParseResult(
        type: .move,
        targetDate: Date("2026-02-13"),
        newDate: Date("2026-02-14T14:00:00+08:00"),
        originalText: "移動今天會議到明天",
        confidence: 1.0
    )
}
```

---

### Phase 2: 根據動作類型執行對應流程

#### 2.1 路由邏輯

```swift
// MainViewModel.send()
switch actionResult.type {
case .create:
    // 原有的新增事件流程
    await parseText()
    
case .delete:
    // 刪除事件流程
    await handleDeleteAction(actionResult: actionResult, originalText: originalText)
    
case .move:
    // 移動事件流程
    await handleMoveAction(actionResult: actionResult, originalText: originalText)
}
```

---

### Phase 3A: 刪除事件流程

#### 3A.1 獲取目標日期的事件

```swift
// MainViewModel.handleDeleteAction()
func handleDeleteAction(actionResult: ActionParseResult, originalText: String) async {
    // 1. 驗證 targetDate
    guard let targetDate = actionResult.targetDate else {
        appState = .error(.custom(message: "無法解析日期"))
        return
    }
    
    // 2. 從日曆獲取該日期的所有事件
    let events = calendarService.fetchEvents(on: targetDate)
    
    // 3. 檢查是否有事件
    guard !events.isEmpty else {
        appState = .error(.custom(
            message: "該日期沒有事件。\n\n提示：如果您確定有事件存在，請確認「日曆」應用程式已開啟並正在運行。"
        ))
        return
    }
    
    // 4. 繼續到事件識別階段
}
```

**CalendarService.fetchEvents() 實作**:
```swift
func fetchEvents(on date: Date) -> [CalendarEventInfo] {
    let calendar = Calendar.current
    let startOfDay = calendar.startOfDay(for: date)
    let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)
    
    // 使用 EventKit 查詢
    let predicate = eventStore.predicateForEvents(withStart: startOfDay, end: endOfDay, calendars: nil)
    let events = eventStore.events(matching: predicate)
    
    // 轉換為 CalendarEventInfo
    return events.map { event in
        CalendarEventInfo(
            id: event.eventIdentifier,
            title: event.title ?? "",
            startDate: event.startDate,
            endDate: event.endDate,
            location: event.location,
            notes: event.notes
        )
    }
}
```

#### 3A.2 AI 事件識別（多個事件時）

```swift
// MainViewModel.handleDeleteAction() 續
var suggestedEventId: String? = nil

if events.count > 1 {
    // 使用 AI 識別最可能的事件
    let identificationResult = try await aiService.identifyEvent(
        from: events,
        userIntent: actionResult.originalText,
        context: context
    )
    
    suggestedEventId = identificationResult.eventId
}
```

**AI 識別 Prompt** (`buildIdentificationPrompt`):
```
User wants to: "刪除明天的會議"

Available events on that date:
1. 09:00 - 10:00 團隊會議 (ID: ABC123)
2. 14:00 - 15:00 客戶會議 (ID: DEF456)
3. 16:00 - 17:00 專案討論 (ID: GHI789)

Which event is the user most likely referring to?

Return JSON:
{
  "eventId": "ABC123",
  "confidence": 0.9
}
```

#### 3A.3 顯示事件選擇 UI

```swift
// MainViewModel.handleDeleteAction() 續
appState = .selectingEvent(
    events: events,
    action: .delete,
    targetDate: nil,
    suggestedEventId: suggestedEventId
)
```

#### 3A.4 EventSelectionView 顯示

**UI 結構**:
```
┌─────────────────────────────────┐
│ ← 返回    選擇要刪除的事件        │
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐  │
│  │ 2月  團隊會議 [AI 推薦]    │  │
│  │ 13   09:00 - 10:00       🗑│  │
│  └───────────────────────────┘  │
│                                 │
│  ┌───────────────────────────┐  │
│  │ 2月  客戶會議              │  │
│  │ 13   14:00 - 15:00       🗑│  │
│  └───────────────────────────┘  │
│                                 │
└─────────────────────────────────┘
```

**EventSelectionView 邏輯**:
```swift
struct EventSelectionView: View {
    let events: [CalendarEventInfo]
    let action: CalendarActionType  // .delete
    let suggestedEventId: String?
    
    // 排序：AI 推薦的排在最前面
    private var sortedEvents: [CalendarEventInfo] {
        var sorted = events
        if let suggestedId = suggestedEventId,
           let suggestedIndex = sorted.firstIndex(where: { $0.id == suggestedId }) {
            let suggested = sorted.remove(at: suggestedIndex)
            sorted.insert(suggested, at: 0)
        }
        return sorted
    }
    
    var body: some View {
        ForEach(sortedEvents) { event in
            EventSelectionCard(
                event: event,
                action: .delete,
                isSuggested: event.id == suggestedEventId,
                onSelect: {
                    Task {
                        await viewModel.executeDelete(
                            eventId: event.id,
                            eventTitle: event.title
                        )
                    }
                }
            )
        }
    }
}
```

**EventSelectionCard 特點**:
- AI 推薦的事件有特殊樣式（高亮、邊框、badge）
- 只有點擊垃圾桶 icon 才執行刪除
- 點擊卡片本身無動作

#### 3A.5 執行刪除

```swift
// MainViewModel.executeDelete()
func executeDelete(eventId: String, eventTitle: String) async {
    appState = .saving
    
    do {
        // 呼叫 CalendarService 刪除事件
        try calendarService.deleteEvent(withIdentifier: eventId)
        
        // 顯示成功訊息
        appState = .success("已刪除事件：\(eventTitle)")
        
        // 2 秒後自動重置
        try await Task.sleep(nanoseconds: 2_000_000_000)
        reset()
    } catch {
        appState = .failure(.custom(
            message: "刪除失敗：\(error.localizedDescription)"
        ))
    }
}
```

**CalendarService.deleteEvent() 實作**:
```swift
func deleteEvent(withIdentifier identifier: String) throws {
    guard let event = eventStore.event(withIdentifier: identifier) else {
        throw AppError.custom(message: "找不到事件")
    }
    
    try eventStore.remove(event, span: .thisEvent, commit: true)
}
```

---

### Phase 3B: 移動事件流程

#### 3B.1 獲取目標日期的事件

```swift
// MainViewModel.handleMoveAction()
func handleMoveAction(actionResult: ActionParseResult, originalText: String) async {
    // 1. 驗證 targetDate 和 newDate
    guard let targetDate = actionResult.targetDate else {
        appState = .error(.custom(message: "無法解析來源日期"))
        return
    }
    
    guard let newDate = actionResult.newDate else {
        appState = .error(.custom(message: "無法解析目標日期"))
        return
    }
    
    // 2. 從日曆獲取該日期的所有事件
    let events = calendarService.fetchEvents(on: targetDate)
    
    // 3. 檢查是否有事件
    guard !events.isEmpty else {
        appState = .error(.custom(
            message: "該日期沒有事件。\n\n提示：如果您確定有事件存在，請確認「日曆」應用程式已開啟並正在運行。"
        ))
        return
    }
    
    // 4. 繼續到事件識別階段
}
```

#### 3B.2 AI 事件識別（同刪除流程）

```swift
// MainViewModel.handleMoveAction() 續
var suggestedEventId: String? = nil

if events.count > 1 {
    let identificationResult = try await aiService.identifyEvent(
        from: events,
        userIntent: actionResult.originalText,
        context: context
    )
    
    suggestedEventId = identificationResult.eventId
}
```

#### 3B.3 顯示事件選擇 UI（含日期選擇器）

```swift
// MainViewModel.handleMoveAction() 續
appState = .selectingEvent(
    events: events,
    action: .move,
    targetDate: newDate,  // 傳入 AI 解析的目標日期
    suggestedEventId: suggestedEventId
)
```

#### 3B.4 EventSelectionView 顯示（移動模式）

**UI 結構**:
```
┌─────────────────────────────────┐
│ ← 返回    選擇要移動的事件        │
├─────────────────────────────────┤
│ 移動到  [2/14 (五) 14:00] ▼     │  ← DatePicker
├─────────────────────────────────┤
│                                 │
│  ┌───────────────────────────┐  │
│  │ 2月  團隊會議 [AI 推薦]    │  │
│  │ 13   09:00 - 10:00        │  │
│  │ → 移動到 2/14 (五)        →│  │
│  └───────────────────────────┘  │
│                                 │
│  ┌───────────────────────────┐  │
│  │ 2月  客戶會議              │  │
│  │ 13   14:00 - 15:00        │  │
│  │ → 移動到 2/14 (五)        →│  │
│  └───────────────────────────┘  │
│                                 │
└─────────────────────────────────┘
```

**EventSelectionView 邏輯（移動模式）**:
```swift
struct EventSelectionView: View {
    @State private var selectedTargetDate: Date
    
    init(viewModel: MainViewModel, events: [CalendarEventInfo], 
         action: CalendarActionType, targetDate: Date?, suggestedEventId: String?) {
        self.viewModel = viewModel
        self.events = events
        self.action = action
        self.suggestedEventId = suggestedEventId
        // 初始化為 AI 解析的目標日期
        self._selectedTargetDate = State(initialValue: targetDate ?? Date())
    }
    
    var body: some View {
        VStack {
            // Header
            Text("選擇要移動的事件")
            
            // DatePicker（只在移動模式顯示）
            if action == .move {
                HStack {
                    Text("移動到")
                    DatePicker("", selection: $selectedTargetDate, 
                              displayedComponents: [.date, .hourAndMinute])
                        .datePickerStyle(.compact)
                }
            }
            
            // 事件列表
            ForEach(sortedEvents) { event in
                EventSelectionCard(
                    event: event,
                    action: .move,
                    targetDate: selectedTargetDate,  // 傳入使用者選擇的日期
                    isSuggested: event.id == suggestedEventId,
                    onSelect: {
                        Task {
                            await viewModel.executeMove(
                                eventId: event.id,
                                eventTitle: event.title,
                                event: event,
                                to: selectedTargetDate  // 使用 DatePicker 的值
                            )
                        }
                    }
                )
            }
        }
    }
}
```

**EventSelectionCard 特點（移動模式）**:
- 顯示目標日期：「→ 移動到 2/14 (五)」
- 目標日期會隨 DatePicker 變化即時更新
- 點擊箭頭 icon 執行移動

#### 3B.5 執行移動

```swift
// MainViewModel.executeMove()
func executeMove(eventId: String, eventTitle: String, 
                event: CalendarEventInfo, to newDate: Date) async {
    appState = .saving
    
    do {
        // 計算事件持續時間
        let duration = event.endDate.timeIntervalSince(event.startDate)
        let newEndDate = newDate.addingTimeInterval(duration)
        
        // 呼叫 CalendarService 移動事件
        try calendarService.moveEvent(
            withIdentifier: eventId,
            to: newDate,
            endDate: newEndDate
        )
        
        // 顯示成功訊息
        appState = .success("已移動事件：\(eventTitle)")
        
        // 2 秒後自動重置
        try await Task.sleep(nanoseconds: 2_000_000_000)
        reset()
    } catch {
        appState = .failure(.custom(
            message: "移動失敗：\(error.localizedDescription)"
        ))
    }
}
```

**CalendarService.moveEvent() 實作**:
```swift
func moveEvent(withIdentifier identifier: String, 
              to newStartDate: Date, endDate newEndDate: Date) throws {
    guard let event = eventStore.event(withIdentifier: identifier) else {
        throw AppError.custom(message: "找不到事件")
    }
    
    // 更新事件時間
    event.startDate = newStartDate
    event.endDate = newEndDate
    
    // 儲存變更
    try eventStore.save(event, span: .thisEvent, commit: true)
}
```

---

## 狀態機

### AppState 定義

```swift
enum AppState {
    case idle
    case parsing
    case selectingEvent(
        events: [CalendarEventInfo],
        action: CalendarActionType,
        targetDate: Date?,
        suggestedEventId: String?
    )
    case saving
    case success(String)
    case failure(AppError)
    case error(AppError)
}
```

### 狀態轉換圖

```
[idle]
  ↓ 使用者輸入
[parsing]
  ↓ AI 解析完成
  ├─ CREATE → [preview] → [saving] → [success] → [idle]
  ├─ DELETE → [selectingEvent] → [saving] → [success] → [idle]
  └─ MOVE   → [selectingEvent] → [saving] → [success] → [idle]
  
錯誤處理：
  任何階段 → [error] → 使用者點擊重試 → [idle]
```

---

## 關鍵設計決策

### 1. 日期格式統一

**問題**: AI 可能返回相對日期字串（"today", "tomorrow"）

**解決方案**: 
- 在 prompt 中明確要求 AI 轉換為 YYYY-MM-DD 或 ISO8601 格式
- 提供當前日期作為參考
- 在 prompt 最後強調：「DO NOT use relative date strings」

### 2. 事件識別策略

**單一事件**: 直接顯示在選擇 UI，不需要 AI 識別

**多個事件**: 
- 使用 AI 識別最可能的事件
- 將 AI 推薦的事件排在最前面
- 使用視覺標記（badge、高亮）
- 使用者仍可選擇其他事件

### 3. 使用者確認機制

**為什麼需要確認**:
- 避免誤刪重要事件
- 讓使用者看到將要操作的事件詳情
- 提供修改目標日期的機會（移動操作）

**實作方式**:
- 不直接執行操作
- 顯示 EventSelectionView 讓使用者確認
- 只有點擊 icon 才執行操作（避免誤觸）

### 4. 日曆系統檢查

**問題**: 如果日曆 app 沒開，EventKit 可能讀不到事件

**解決方案**:
- 在錯誤訊息中提示使用者
- 訊息：「該日期沒有事件。\n\n提示：如果您確定有事件存在，請確認「日曆」應用程式已開啟並正在運行。」

### 5. 移動操作的日期處理

**targetDate vs newDate**:
- `targetDate`: 事件**目前所在**的日期（來源）
- `newDate`: 事件要**移動到**的日期（目標）

**DatePicker 初始值**:
- 使用 AI 解析的 `newDate` 作為初始值
- 使用者可以調整為任意日期時間

**持續時間保持**:
- 計算原事件的持續時間
- 移動後保持相同的持續時間

---

## 錯誤處理

### 常見錯誤情境

1. **無法解析日期**
   - 錯誤訊息：「無法解析日期」
   - 恢復動作：返回 idle，讓使用者重新輸入

2. **該日期沒有事件**
   - 錯誤訊息：「該日期沒有事件。\n\n提示：如果您確定有事件存在，請確認「日曆」應用程式已開啟並正在運行。」
   - 恢復動作：返回 idle

3. **找不到事件**
   - 錯誤訊息：「找不到事件」
   - 可能原因：事件已被其他應用刪除
   - 恢復動作：返回 idle

4. **刪除/移動失敗**
   - 錯誤訊息：「刪除失敗：[具體錯誤]」
   - 可能原因：權限問題、事件被鎖定
   - 恢復動作：顯示 failure 狀態，使用者可重試

---

## 測試場景

### 刪除事件

1. ✅ 刪除今天的單一事件
2. ✅ 刪除明天的多個事件（AI 識別）
3. ✅ 刪除不存在的事件（錯誤處理）
4. ✅ 日曆 app 未開啟（錯誤提示）

### 移動事件

1. ✅ 移動今天的事件到明天
2. ✅ 移動事件並手動調整目標時間
3. ✅ 移動多個事件中的一個（AI 識別）
4. ✅ 移動到過去的日期（應該允許）
5. ✅ 保持事件持續時間

### AI 解析

1. ✅ 相對日期轉換（今天、明天、昨天）
2. ✅ 具體日期解析（2月14日）
3. ✅ 時間解析（下午2點、14:00）
4. ✅ 中英文混合輸入

---

## 未來改進方向

### 1. 批量操作
- 支援一次刪除/移動多個事件
- 例如：「刪除本週所有會議」

### 2. 更智能的事件識別
- 考慮事件標題的語義相似度
- 考慮事件時間（上午/下午）
- 考慮事件地點

### 3. 撤銷功能
- 刪除後可以撤銷
- 移動後可以恢復原位置

### 4. 更多日期格式支援
- 「下週五」
- 「三天後」
- 「月底」

### 5. 事件預覽
- 在選擇 UI 顯示更多事件詳情
- 顯示事件的完整描述、參與者等

---

## 總結

刪除和移動事件功能通過以下設計實現了良好的使用者體驗：

1. **智能意圖識別** - AI 自動判斷使用者想要執行的操作
2. **精確事件定位** - 結合日期過濾和 AI 識別
3. **使用者確認機制** - 避免誤操作
4. **靈活的日期調整** - 移動操作支援手動調整目標日期
5. **清晰的錯誤提示** - 幫助使用者理解和解決問題

整個流程保持了與原有新增事件功能一致的設計風格，提供了流暢的使用體驗。
