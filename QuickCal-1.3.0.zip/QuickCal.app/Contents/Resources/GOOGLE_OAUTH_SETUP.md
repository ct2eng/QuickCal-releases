# Google OAuth Setup Guide

## 重要：Desktop App 必須使用 PKCE

Desktop 和 Mobile 應用程式應該使用 **PKCE（Proof Key for Code Exchange）** 而不是 client_secret。

## 步驟 1：建立 Google Cloud 專案

1. 前往 [Google Cloud Console](https://console.cloud.google.com/)
2. 建立新專案或選擇現有專案
3. 記下專案名稱

## 步驟 2：啟用 Google Calendar API

1. 在左側選單中，前往「APIs & Services」→「Library」
2. 搜尋「Google Calendar API」
3. 點擊「Enable」啟用 API

## 步驟 3：建立 OAuth 2.0 Client ID（Desktop App）

### ⚠️ 重要：必須選擇「Desktop app」類型

1. 前往「APIs & Services」→「Credentials」
2. 點擊「+ CREATE CREDENTIALS」→「OAuth client ID」
3. **應用程式類型：選擇「Desktop app」** ← 這是關鍵！
   - ❌ 不要選「Web application」（需要 client_secret）
   - ✅ 選「Desktop app」（支援 PKCE）
4. 名稱：輸入「QuickCal」或任何你喜歡的名稱
5. 點擊「Create」

### 取得 Client ID

建立完成後，你會看到：
- ✅ Client ID：`770334830014-xxxxxxxxxx.apps.googleusercontent.com`
- ⚠️ Client Secret：可以忽略（Desktop app 不需要）

**複製 Client ID** 並更新到 `GoogleAuthService.swift`：

```swift
private let clientId = "YOUR_CLIENT_ID_HERE"
```

## 步驟 4：設定 OAuth Consent Screen

1. 前往「APIs & Services」→「OAuth consent screen」
2. User Type：選擇「External」
3. 填寫必要資訊：
   - App name：QuickCal
   - User support email：你的 email
   - Developer contact information：你的 email
4. 點擊「Save and Continue」

### Scopes（權限範圍）

1. 點擊「Add or Remove Scopes」
2. 搜尋並勾選：
   - `https://www.googleapis.com/auth/calendar`
3. 點擊「Update」→「Save and Continue」

### Test Users（測試用戶）

在發布前，你需要加入測試用戶：

1. 點擊「+ ADD USERS」
2. 輸入你的 Google 帳號 email
3. 點擊「Save」

**注意：** 在 app 發布前，只有測試用戶可以登入。

## 步驟 5：更新程式碼

在 `GoogleAuthService.swift` 中更新 Client ID：

```swift
private let clientId = "YOUR_CLIENT_ID_HERE"  // 從 Google Cloud Console 複製
```

**不需要設定 client_secret**，因為 Desktop app 使用 PKCE。

## 驗證設定

### 檢查 OAuth Client 類型

1. 前往「APIs & Services」→「Credentials」
2. 找到你建立的 OAuth 2.0 Client ID
3. 確認「Type」欄位顯示「Desktop」

如果顯示「Web application」，你需要：
- 刪除舊的 credential
- 重新建立一個「Desktop app」類型的 credential

## 常見問題

### Q: 為什麼我收到「client_secret is missing」錯誤？

A: 這表示你建立的是「Web application」類型的 OAuth Client，而不是「Desktop app」。請重新建立一個「Desktop app」類型的 credential。

### Q: Desktop app 和 Web application 有什麼差別？

A: 
- **Web application**：需要 client_secret（後端伺服器使用）
- **Desktop app**：使用 PKCE（不需要 client_secret，更安全）

### Q: 我可以同時有多個 OAuth Client ID 嗎？

A: 可以。你可以為不同平台建立不同的 credential：
- Desktop app（macOS）
- iOS app
- Web application（如果有網頁版）

### Q: 測試用戶有數量限制嗎？

A: 在 app 未發布前，最多可以加入 100 個測試用戶。

## 發布應用程式

當你準備好發布時：

1. 前往「OAuth consent screen」
2. 點擊「Publish App」
3. 提交 Google 審核（如果需要敏感權限）

**注意：** Google Calendar API 需要審核，審核時間通常為 1-2 週。

## Redirect URI

Desktop app 的 redirect URI 格式：

```
com.googleusercontent.apps.YOUR_CLIENT_ID:/oauth2redirect
```

例如：
```
com.googleusercontent.apps.770334830014-q6t06rfqulao61irdgolfafpbthin2hs:/oauth2redirect
```

這個 URI 會自動由 `ASWebAuthenticationSession` 處理，不需要在 Google Cloud Console 中手動設定。

## 安全性最佳實踐

✅ 使用 Desktop app 類型（支援 PKCE）
✅ 不要在程式碼中儲存 client_secret
✅ 使用 Keychain 儲存 tokens
✅ 定期更新 access token
✅ 提供 sign out 功能

## 參考資料

- [Google OAuth 2.0 for Mobile & Desktop Apps](https://developers.google.com/identity/protocols/oauth2/native-app)
- [OAuth 2.0 PKCE](https://tools.ietf.org/html/rfc7636)
- [Google Calendar API](https://developers.google.com/calendar/api/guides/overview)
