# 修復 Keychain 權限重複詢問問題

## 問題
每次應用程式存取 Keychain 時，macOS 都會跳出權限詢問視窗。

## 解決方案 ✅

### 使用現代 Keychain API + 正確的 Accessibility 設定
應用程式現在使用 Apple 官方建議的 OAuth token 儲存方式：

**關鍵設定：**
```swift
kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
```

這個設定告訴 macOS：
- ✅ 裝置解鎖後可存取（開機後解鎖一次即可）
- ✅ 僅限此裝置（不同步到 iCloud）
- ✅ App sandbox 資料（不需要用戶權限提示）

### 為什麼這樣有效
- **舊 API** (`SecKeychain` / 錯誤的 accessibility) → 永遠會詢問用戶
- **現代 API** (`SecItemAdd` + `AfterFirstUnlockThisDeviceOnly`) → 不會跳出提示

這是 **Apple 官方文件建議** 的 OAuth token 儲存方式。

## 實作細節

### Keychain 操作 (GoogleAuthService.swift)
```swift
// 儲存 token（不會跳出權限提示）
let addQuery: [String: Any] = [
    kSecClass as String: kSecClassGenericPassword,
    kSecAttrService as String: keychainService,
    kSecAttrAccount as String: key,
    kSecValueData as String: data,
    // ⭐ 這個設定防止權限提示
    kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
]
SecItemAdd(addQuery as CFDictionary, nil)
```

### Entitlements 設定
已加入到 `QuickCal.entitlements`：
```xml
<key>keychain-access-groups</key>
<array>
    <string>$(AppIdentifierPrefix)com.quickcal.google</string>
</array>
```

## 疑難排解

### 如果還是會跳出提示

1. **清理舊的 Keychain 項目**（它們可能有錯誤的 accessibility 設定）：
```bash
security delete-generic-password -s "com.quickcal.google" -a "google_access_token"
security delete-generic-password -s "com.quickcal.google" -a "google_refresh_token"
```

2. **重新編譯應用程式** 確保新的 Keychain 程式碼生效：
```bash
# 在 Xcode 中：Product → Clean Build Folder (Cmd+Shift+K)
# 然後：Product → Build (Cmd+B)
```

3. **檢查程式碼簽署**：
   - 確保應用程式在 Xcode 中正確簽署
   - 前往：Signing & Capabilities 標籤
   - 確認「Automatically manage signing」已啟用

4. **App Sandbox 考量**：
   - 目前在 entitlements 中停用（`<false/>`）
   - 這對開發來說沒問題，但可能造成問題
   - 如果問題持續，考慮啟用 App Sandbox

### 驗證是否正常運作

重新編譯後，檢查 Console.app 日誌：
- ✅ `Successfully saved token 'google_access_token' to Keychain (no prompt)`
- ✅ `Successfully loaded token 'google_access_token' from Keychain`

不應該出現任何權限對話框。

## 安全性說明

### 這樣安全嗎？
**是的。** 這是 OAuth token 的建議做法：
- Token 在 Keychain 中加密
- 受 macOS 安全性保護
- App sandbox 隔離
- 不同步到 iCloud（僅限裝置）

### Accessibility 等級比較
| 等級 | 使用情境 | 會詢問用戶？ |
|------|---------|-------------|
| `WhenUnlocked` | 密碼、敏感資料 | ✅ 是 |
| `AfterFirstUnlock` | 一般應用程式資料 | 有時候 |
| `AfterFirstUnlockThisDeviceOnly` | OAuth tokens（建議） | ❌ 否 |
| `Always` | 背景服務 | ❌ 否（但較不安全） |

根據 Apple 指南，OAuth token 應該使用 `AfterFirstUnlockThisDeviceOnly`。

## 為什麼需要 Keychain？

- **安全儲存**：OAuth tokens 需要安全儲存，不能放在普通檔案中
- **自動登入**：下次啟動應用程式時自動恢復登入狀態
- **系統級保護**：Keychain 由 macOS 加密保護
- **標準做法**：所有 OAuth 應用程式都使用 Keychain

## 注意事項

- QuickCal 只會存取自己的 Keychain 項目（服務名稱：`com.quickcal.google`）
- 不會存取其他應用程式的密碼或憑證
- 不會存取你的系統密碼
- 完全安全且符合 macOS 安全最佳實踐
