# Google OAuth with PKCE for Desktop Apps

## 什麼是 PKCE？

PKCE（Proof Key for Code Exchange，發音 "pixy"）是 OAuth 2.0 的安全擴展，專為 Desktop 和 Mobile 應用程式設計。

## 為什麼 Desktop App 要用 PKCE？

### ❌ 錯誤做法：使用 Client Secret
```swift
// 不安全！Desktop app 不應該這樣做
let body = [
    "client_id": clientId,
    "client_secret": clientSecret,  // ❌ 會被反編譯取得
    "code": code
]
```

**問題：**
- Client Secret 會被打包進 app
- 任何人都可以反編譯取得
- 無法保密

### ✅ 正確做法：使用 PKCE
```swift
// 安全！每次登入都產生新的一次性密碼
let body = [
    "client_id": clientId,
    "code_verifier": verifier,  // ✅ 一次性隨機字串
    "code": code
]
```

**優點：**
- 每次登入產生新的隨機密碼
- 即使被攔截也無法重複使用
- OAuth 2.0 標準做法

## PKCE 流程

### 1. 產生 PKCE 參數

```swift
// 產生隨機字串 (43-128 字元)
let codeVerifier = generateRandomString(length: 64)

// 計算 SHA256 hash 並 base64url 編碼
let codeChallenge = sha256Base64URL(codeVerifier)
```

### 2. 開啟登入頁面（帶上 code_challenge）

```
https://accounts.google.com/o/oauth2/v2/auth?
  client_id=xxx
  &redirect_uri=xxx
  &response_type=code
  &scope=xxx
  &code_challenge=xxx           ← 送 hash
  &code_challenge_method=S256   ← 使用 SHA256
```

### 3. 換取 Token（送 code_verifier）

```
POST https://oauth2.googleapis.com/token
  client_id=xxx
  &code=xxx
  &code_verifier=xxx  ← 送原始字串
  &grant_type=authorization_code
```

### 4. Google 驗證

Google 會：
1. 計算 `SHA256(code_verifier)`
2. 比對是否等於之前收到的 `code_challenge`
3. 相同 → 通過 ✅
4. 不同 → 拒絕 ❌

## 實作細節

### 產生隨機字串

```swift
func generateRandomString(length: Int) -> String {
    let characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"
    return String((0..<length).map { _ in characters.randomElement()! })
}
```

### 計算 SHA256 + Base64URL

```swift
func sha256Base64URL(_ input: String) -> String {
    guard let data = input.data(using: .utf8) else { return "" }
    
    var hash = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
    data.withUnsafeBytes {
        _ = CC_SHA256($0.baseAddress, CC_LONG(data.count), &hash)
    }
    
    let hashData = Data(hash)
    return hashData.base64EncodedString()
        .replacingOccurrences(of: "+", with: "-")
        .replacingOccurrences(of: "/", with: "_")
        .replacingOccurrences(of: "=", with: "")
}
```

**注意：** Base64URL 編碼與標準 Base64 的差異：
- `+` → `-`
- `/` → `_`
- 移除 `=` padding

## Google Cloud Console 設定

### 建立 OAuth 2.0 Client ID

1. 前往 [Google Cloud Console](https://console.cloud.google.com/)
2. 選擇專案
3. 啟用 Google Calendar API
4. 建立憑證 → OAuth 2.0 Client ID
5. **應用程式類型：選擇「Desktop app」** ← 重要！
6. 複製 Client ID

### ⚠️ 不需要 Client Secret

Desktop app 類型的 OAuth credentials：
- ✅ 會給你 Client ID
- ❌ 不需要 Client Secret（或可以忽略）
- ✅ 使用 PKCE 取代

## 安全性比較

| 方案 | 安全性 | 適用場景 |
|------|--------|----------|
| Client Secret | ❌ 低 | Web Server（後端） |
| PKCE | ✅ 高 | Desktop / Mobile App |
| PKCE + Client Secret | ✅ 最高 | 某些特殊情況 |

## 常見問題

### Q: 為什麼我之前用 Client Secret 可以成功？

A: 因為你在 Google Cloud Console 選擇了「Web application」類型，而不是「Desktop app」。Web application 類型需要 Client Secret，但這不適合 Desktop app。

### Q: PKCE 會不會比較慢？

A: 不會。SHA256 計算非常快速（< 1ms），使用者完全感覺不到。

### Q: Refresh Token 也需要 PKCE 嗎？

A: 不需要。只有第一次換取 token 時需要 PKCE。Refresh token 請求不需要 PKCE 或 Client Secret。

```swift
// Refresh token request (不需要 PKCE)
let body = [
    "refresh_token": refreshToken,
    "client_id": clientId,
    "grant_type": "refresh_token"
]
```

## 參考資料

- [RFC 7636 - PKCE](https://tools.ietf.org/html/rfc7636)
- [Google OAuth 2.0 for Mobile & Desktop Apps](https://developers.google.com/identity/protocols/oauth2/native-app)
- [OAuth 2.0 Best Practices](https://tools.ietf.org/html/draft-ietf-oauth-security-topics)

## 總結

✅ Desktop app 使用 PKCE（不用 Client Secret）
✅ 每次登入產生新的隨機 code_verifier
✅ 送 code_challenge（SHA256 hash）給 Google
✅ 換 token 時送 code_verifier 驗證
✅ 安全、標準、簡單
