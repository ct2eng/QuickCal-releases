# QuickCal - AI Calendar Parser

A macOS Menu Bar application that uses Apple Intelligence to parse meeting text and create calendar events.

## Project Structure

``` 
QuickCal/
├── Models/          # Data models (MeetingEvent, MeetingParseResult, AppState, AppError)
├── Services/        # Business logic services (AIParsingService, CalendarService, DateParserService)
├── ViewModels/      # MVVM ViewModels (MainViewModel)
├── Views/           # SwiftUI Views (InputView, PreviewView, etc.)
├── Assets.xcassets/ # App assets and icons
├── Info.plist       # App configuration (LSUIElement = true)
└── QuickCalApp.swift # App entry point

QuickCalTests/       # Unit tests and property-based tests
```

## Requirements

- macOS 15.0 or later
- Apple Intelligence enabled
- Xcode 16.0 or later

## Frameworks

- **SwiftUI**: UI framework
- **EventKit**: Calendar integration
- **Foundation**: Core functionality
- **SwiftCheck**: Property-based testing (test target only)

## Configuration

- **LSUIElement**: Set to `true` in Info.plist (no Dock icon)
- **Deployment Target**: macOS 15.0
- **Timezone**: Asia/Taipei (UTC+08:00)
- **Locale**: zh-TW (Traditional Chinese - Taiwan)

## Architecture

The app follows MVVM (Model-View-ViewModel) architecture:

- **Models**: Pure data structures (MeetingEvent, MeetingParseResult, AppState, AppError)
- **Services**: Business logic and external integrations (AI parsing, calendar access, date handling)
- **ViewModels**: State management and coordination between Views and Services
- **Views**: SwiftUI UI components

## Testing

The project uses a dual testing approach:

1. **Unit Tests**: Test specific examples and edge cases
2. **Property-Based Tests**: Test universal properties across all inputs using SwiftCheck

See `.kiro/specs/ai-calendar-parser/design.md` for detailed testing strategy.
