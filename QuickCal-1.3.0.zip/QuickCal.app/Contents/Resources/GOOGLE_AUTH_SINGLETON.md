# Google 認證服務單例模式

## 問題

之前的實現中，`GoogleAuthService` 在不同地方被多次實例化：
- `QuickCalApp.swift` 創建一個實例用於主應用程式
- `CalendarSettingsView.swift` 創建另一個實例用於設定頁面

這導致：
1. 在 Settings 中登入 Google 後，主應用程式無法看到登入狀態
2. 創建 event 時會再次要求登入
3. 認證狀態不一致

## 解決方案

將 `GoogleAuthService` 改為單例模式（Singleton Pattern）：

```swift
class GoogleAuthService: NSObject, ObservableObject {
    // Shared instance for application-wide authentication state
    static let shared = GoogleAuthService()
    
    // ... rest of the implementation
}
```

## 使用方式

現在整個應用程式都使用同一個實例：

```swift
// 在 QuickCalApp.swift
let googleProvider = GoogleCalendarProvider(authService: GoogleAuthService.shared)

// 在 CalendarSettingsView.swift
@ObservedObject private var googleAuthService = GoogleAuthService.shared
```

## 好處

1. **一致的認證狀態**：整個應用程式共享同一個認證狀態
2. **只需登入一次**：在 Settings 登入後，所有功能都可以使用
3. **自動同步**：`@ObservedObject` 確保 UI 自動更新
4. **Keychain 共享**：所有地方都存取同一個 Keychain 項目

## 注意事項

- 單例模式確保只有一個 `GoogleAuthService` 實例存在
- 所有 OAuth tokens 都儲存在 Keychain 中（服務名稱：`com.quickcal.google`）
- 登入狀態在應用程式重啟後會自動恢復（從 Keychain 讀取）
