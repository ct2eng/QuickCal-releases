# 修復 403 Access Denied 錯誤

## 問題

當你點擊「Sign in with Google」時看到：

```
Error 403: access_denied
QuickCal has not completed the Google verification process.
The app is currently being tested, and can only be accessed by developer-approved testers.
```

## 原因

你的 Google 帳號還沒有被加入到應用程式的「測試使用者」清單中。

## 解決方法（5 分鐘）

### 步驟 1：前往 OAuth 同意畫面

1. 開啟 [Google Cloud Console](https://console.cloud.google.com/)
2. 確認你選擇了正確的專案（QuickCal）
3. 左側選單點擊「API 和服務」→「OAuth 同意畫面」

### 步驟 2：新增測試使用者

1. 在 OAuth 同意畫面頁面，捲動到「測試使用者」區塊
2. 點擊「+ ADD USERS」按鈕
3. 在彈出的對話框中，輸入你的 Google 帳號電子郵件地址
   - 例如：`your.email@gmail.com`
   - 這應該是你剛才嘗試登入時使用的帳號
4. 點擊「新增」
5. 點擊「儲存」

### 步驟 3：重新嘗試登入

1. 回到 QuickCal 應用程式
2. 前往 Settings → Calendar Settings
3. 確認選擇了 Google Calendar
4. 點擊「Sign in with Google」
5. 這次應該能成功看到 Google 登入頁面

## 視覺指南

```
Google Cloud Console
└── 選擇專案：QuickCal
    └── API 和服務
        └── OAuth 同意畫面
            └── 測試使用者
                └── + ADD USERS
                    └── 輸入你的 email
                        └── 新增
                            └── 儲存
```

## 驗證成功

成功新增測試使用者後，你應該能看到：

1. 你的電子郵件地址出現在「測試使用者」清單中
2. 重新登入時，Google 會顯示正常的登入頁面
3. 登入後會要求授權 QuickCal 存取你的 Google Calendar

## 注意事項

- **測試階段限制**：應用程式在測試階段最多可以新增 100 個測試使用者
- **只需新增一次**：每個 Google 帳號只需要新增一次
- **多個帳號**：如果你想用多個 Google 帳號測試，需要將每個帳號都加入測試使用者清單

## 還是不行？

如果新增測試使用者後還是看到 403 錯誤，檢查：

1. **確認專案正確**：確保你在正確的 Google Cloud 專案中新增測試使用者
2. **確認電子郵件正確**：測試使用者的電子郵件必須與你登入時使用的完全一致
3. **確認 Client Secret 已設定**：如果看到「Could not exchange authorization code」錯誤，表示缺少 Client Secret
4. **等待幾分鐘**：有時候 Google 需要幾分鐘來同步設定
5. **清除瀏覽器快取**：如果使用外部瀏覽器，嘗試清除快取或使用無痕模式
6. **檢查 OAuth 同意畫面狀態**：確認 OAuth 同意畫面已完成設定並儲存

## 長期解決方案

如果你想讓任何人都能使用（不只是測試使用者），你需要：

1. 在 OAuth 同意畫面點擊「發布應用程式」
2. 提交 Google 審核（可能需要幾週時間）
3. 通過審核後，任何 Google 帳號都能登入

但對於個人使用或小團隊測試，使用測試使用者清單就足夠了。

## 快速檢查清單

- [ ] 已前往 Google Cloud Console
- [ ] 已選擇正確的專案
- [ ] 已進入「OAuth 同意畫面」
- [ ] 已點擊「+ ADD USERS」
- [ ] 已輸入正確的 Google 帳號電子郵件
- [ ] 已點擊「新增」和「儲存」
- [ ] 已回到 QuickCal 重新嘗試登入
- [ ] 成功看到 Google 登入頁面

完成以上步驟後，你應該就能成功登入 Google Calendar 了！

## 其他常見錯誤

### "Could not exchange authorization code" 錯誤

如果你能成功看到 Google 登入頁面並完成登入，但回到應用程式後看到「Could not exchange authorization code」錯誤，這表示缺少 Client Secret。

**解決方法：**

1. 前往 [Google Cloud Console](https://console.cloud.google.com/)
2. 選擇你的專案
3. 左側選單選擇「API 和服務」→「憑證」
4. 找到你的 OAuth 2.0 用戶端 ID，點擊右側的編輯圖示（鉛筆）
5. 在頁面上方複製「用戶端密鑰」（Client Secret）
6. 開啟 `QuickCal/Services/GoogleAuthService.swift`
7. 找到這一行：
   ```swift
   private let clientSecret = ""
   ```
8. 替換成你的 Client Secret：
   ```swift
   private let clientSecret = "GOCSPX-你的密鑰"
   ```
9. 重新編譯並執行應用程式

**為什麼需要 Client Secret？**

桌面應用程式（Desktop app）類型的 OAuth 憑證需要 Client Secret 才能完成 token 交換。這是 Google OAuth 2.0 的標準流程。

**檢查 Console 輸出：**

如果還是有問題，可以查看 Xcode 的 Console 輸出。應用程式現在會顯示詳細的錯誤訊息，例如：
```
❌ Token exchange failed with status 400
❌ Error response: {"error":"invalid_client","error_description":"..."}
```

這些訊息可以幫助診斷問題。
