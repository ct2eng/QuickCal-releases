# QuickCal 主題色配置

## 主題色定義

QuickCal 使用統一的主題色系統，所有顏色定義在 `AppTheme.swift` 中。

### 主要品牌色

#### Primary (主色) - `#4990BB`
- **RGB**: `rgb(73, 144, 187)`
- **用途**: 
  - 按鈕背景色
  - 連結文字顏色
  - 主要操作按鈕
  - 強調元素
  - 送出按鈕圓圈背景
- **使用位置**:
  - InputView: 送出按鈕圓圈
  - PreviewView: 返回按鈕文字顏色

#### Primary Dark (深色變體) - `#3A7A9A`
- **RGB**: `rgb(58, 122, 154)`
- **用途**:
  - 漸變背景的第二個顏色
  - 懸停狀態
  - 按鈕陰影
- **使用位置**:
  - PreviewView: 新增按鈕漸變背景

### 語義顏色

- **Success (成功)**: 系統綠色 - 用於成功狀態、確認操作
- **Warning (警告)**: 系統橘色 - 用於警告訊息、需要注意的狀態
- **Error (錯誤)**: 系統紅色 - 用於錯誤訊息、危險操作
- **Info (資訊)**: 使用主色 `#4990BB` - 用於資訊提示

## 使用方式

### 方式一：直接使用 AppTheme

```swift
// 使用主色
.foregroundColor(AppTheme.primary)

// 使用漸變
.background(AppTheme.primaryGradient)

// 使用陰影
.shadow(color: AppTheme.primary.opacity(0.3), radius: 4, y: 2)
```

### 方式二：使用 Color.Theme 快捷方式

```swift
// 使用主色
.foregroundColor(Color.Theme.primary)

// 使用語義顏色
.foregroundColor(Color.Theme.success)
.foregroundColor(Color.Theme.warning)
.foregroundColor(Color.Theme.error)
```

## 預設樣式

### Primary Gradient (主色漸變)
- 從 `#4990BB` (左上) 到 `#3A7A9A` (右下)
- 用於按鈕背景、卡片背景等

### Primary Shadow (主色陰影)
- 顏色: 主色 + 30% 透明度
- 半徑: 4pt
- Y 偏移: 2pt

## 修改主題色

如果需要更改主題色，只需修改 `AppTheme.swift` 中的顏色定義：

```swift
struct AppTheme {
    static let primary = Color(hex: "#4990BB")  // 修改這裡
    static let primaryDark = Color(hex: "#3A7A9A")  // 修改這裡
}
```

所有使用主題色的地方都會自動更新。

## 已應用主題色的檔案

- `QuickCal/Views/InputView.swift` - 送出按鈕
- `QuickCal/Views/PreviewView.swift` - 返回按鈕、新增按鈕
- 未來新增的 UI 元素也應該使用 `AppTheme` 來保持一致性

## 設計原則

1. **一致性**: 所有主要操作使用主色 `#4990BB`
2. **可訪問性**: 確保顏色對比度符合 WCAG 標準
3. **語義化**: 使用語義顏色（success/warning/error）來傳達狀態
4. **集中管理**: 所有顏色定義在 `AppTheme.swift`，避免硬編碼
