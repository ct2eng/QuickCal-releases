Spec: Screenshot → Inline Image Preview → OCR on Send (macOS Menu Bar App)

1. Goal

在 macOS Menu Bar App（QuickCal）中新增「相機截圖」流程：
	•	使用者點擊 InputView 工具列中的 相機 icon
	•	App 視窗縮小並「收回到 menu bar」的關閉動畫
	•	游標變成十字，使用者框選區域截圖
	•	截圖完成後 App 自動展開（顯示原視窗）
	•	在 InputView 的文字輸入框內 偏下方顯示截圖縮圖（右上角可刪除），文字仍可在上方輸入
	•	使用者按送出（arrow send）時，若有圖片：
	•	先用 **macOS 本機 OCR（Vision）**把圖片轉成文字
	•	將 OCR 文字與使用者輸入文字合併後，走原本 parse 流程（送 API/解析）

⸻

2. User Experience (UX Flow)

2.1 Primary Flow
	1.	使用者在 InputView 內點擊相機 icon
	2.	App 視窗執行「縮回/收起」動畫（和 user 手動關閉視窗一致的視覺效果）並隱藏
	3.	進入截圖模式：
	•	滑鼠游標變十字準星（crosshair）
	•	使用者拖曳框選螢幕區域
	4.	使用者放開滑鼠後完成截圖：
	•	擷取出 NSImage/CGImage
	•	App 視窗自動展開顯示（focus 回到 app）
	5.	InputView 輸入框內顯示圖片縮圖：
	•	位置在文字框下半部但仍屬於同一個輸入框元件
	•	上半部仍可輸入文字（多行）
	•	圖片右上角提供刪除 X
	6.	使用者按送出（arrow up）：
	•	若圖片存在：先 OCR → 得到文字 → 與 inputText 合併 → parseText() 原流程
	•	若圖片不存在：維持現有文字 parse 流程

2.2 Cancel / Escape
	•	使用者在截圖模式按 Esc：取消截圖
	•	App 回到原狀態（展開顯示 InputView）
	•	不插入圖片
	•	使用者框選截圖後，若 OCR 或 parse 失敗，顯示 error card（既有錯誤 UI）

⸻

3. State Machine

新增狀態（可在 MainViewModel 或 AppState 擴充）：
	•	idle：正常輸入
	•	capturing：截圖模式（app 收起，游標十字）
	•	previewingImage：已捕捉圖片，輸入框顯示縮圖（仍可輸入文字）
	•	ocrProcessing：按送出後正在 OCR
	•	parsing：你現有的 parsing 狀態（送 API/解析）
	•	error(AppError)：你現有 error 狀態

狀態轉移：
	•	idle → capturing（點相機）
	•	capturing → previewingImage（完成截圖）
	•	capturing → idle（Esc 取消）
	•	previewingImage → idle（刪除圖片後且文字為空/或維持 idle）
	•	previewingImage → ocrProcessing（按送出）
	•	ocrProcessing → parsing（OCR 成功後進入 parse）
	•	ocrProcessing → error（OCR 失敗）
	•	parsing → idle / error（你現有流程）

⸻

4. UI Requirements

4.1 Toolbar (InputView inline composer bar)
	•	新增 相機 icon，置於 + / globe / paperclip 同區
	•	點擊相機 icon 行為：viewModel.startScreenshotCapture()

4.2 Inline Image Preview inside TextEditor box

在 textEditorCard 內部（同一個輸入框背景）顯示：
	•	圖片顯示區位於底部工具列上方、偏下方
	•	圖片縮圖建議：
	•	max height: 80–120
	•	圓角：8
	•	視覺上與輸入框整體一致（無獨立浮動卡片）
	•	右上角有刪除按鈕（X）：
	•	點擊後移除圖片，恢復只有文字輸入
	•	圖片存在時需調整 TextEditor 的 bottom padding：
	•	bottom padding = toolbar height + image height + spacing
	•	確保文字輸入區不被圖片/toolbar 蓋住

4.3 Send Button Enablement
	•	Send 只在以下條件可點：
	•	inputText 非空白 OR 圖片存在
	•	AI 可用（你原本 check）
	•	非 loading
	•	可點時 send 背景色：#4990BB
	•	不可點時：灰色/降低 opacity（維持你現有 disabled style）

⸻

5. Screenshot Capture Implementation

5.1 Capture Method

使用 macOS 原生截圖體驗（準星、框選、Esc 取消），優先考量：
	•	最貼近系統行為
	•	不需自行繪製 overlay UI

建議方案（擇一）：
	•	A) 呼叫系統截圖工具 screencapture -i 並輸出到 temp 檔，再讀回 image
	•	B) 使用 ScreenCaptureKit / CGWindowListCreateImage 等自行框選（成本高，不建議第一版）

MVP 建議：A (screencapture -i)
	•	-i 進入互動框選
	•	可加 -x 靜音
	•	輸出到 NSTemporaryDirectory()/quickcal_capture.png
	•	若使用者取消，command return code ≠ 0 → 視為取消

5.2 “縮回到 menu bar”動畫需求
	•	點相機後，視窗需要以與你現有收起相同的方式關閉（使用者感覺是縮回 menu bar）
	•	實作上可接受：
	•	NSWindow.performClose(nil) 或 window.orderOut(nil) + animate alpha/scale
	•	Animation 以 0.15–0.25s 內完成

完成截圖後：
	•	window.makeKeyAndOrderFront(nil)
	•	重新 focus（必要時 NSApp.activate(ignoringOtherApps: true)）

⸻

6. OCR Requirements (Local, Free)

6.1 OCR Engine

使用 Apple Vision：
	•	VNRecognizeTextRequest
	•	語言支援至少：
	•	["zh-Hant", "en-US", "ko-KR"]
	•	recognitionLevel = .accurate
	•	usesLanguageCorrection = true

6.2 OCR Trigger
	•	只有在「按送出」且 capturedImage != nil 時才 OCR
	•	OCR 成果作為純文字輸出（不需要保留 layout）

6.3 OCR Text Output
	•	將識別出的 lines 以 \n 連接
	•	合併策略：
	•	若使用者 inputText 也有內容：inputText + "\n\n" + ocrText
	•	若 inputText 為空：ocrText

合併後交給現有 parseText()（或新增 parse(text:) 入口）

⸻

7. Data Model Changes

在 MainViewModel 新增：
	•	@Published var capturedImage: NSImage?
	•	@Published var captureState: CaptureState（或沿用 appState 也可）

新增 methods：
	•	func startScreenshotCapture()
	•	func removeCapturedImage()
	•	func send()（取代目前 send 按鈕直接呼叫 parseText；內部判斷 OCR/文字）

新增 service：
	•	ScreenshotService：封裝 screencapture 呼叫、temp file、取消偵測、回傳 NSImage
	•	OCRService：Vision OCR，輸入 CGImage/NSImage，回傳 String

⸻

8. Error Handling
	•	截圖取消（Esc）：不顯示 error，回到 idle
	•	截圖失敗（無法執行、無權限、temp file missing）：
	•	顯示 errorCard："Screenshot failed" + retry（retry=重新截圖）
	•	OCR 失敗：
	•	顯示 errorCard："OCR failed" + retry（retry=重新 OCR 或重新截圖）
	•	OCR 成功但無文字：
	•	顯示 warning（可選）："No text found"，仍允許送出（送空文字會被擋住）
	•	MVP：當作空字串，若 inputText 也空就 disable send

⸻

9. Non-Functional Requirements
	•	OCR 必須在背景 thread 執行（async/await）
	•	UI 不可卡頓（期間顯示 loading overlay 或小 spinner）
	•	截圖 temp file 需在成功讀取後刪除
	•	不上傳圖片到任何第三方（只本機 OCR）
	•	具備可測試性：OCRService / ScreenshotService 可被 mock

⸻

10. Acceptance Criteria (驗收標準)
	1.	點相機 icon → app 視窗收起，游標變十字，可框選截圖
	2.	Esc 可取消，不插入圖片，app 回到正常
	3.	完成截圖 → app 展開，輸入框內下半部顯示圖片縮圖，右上角可刪除
	4.	圖片存在時，上半部仍可輸入文字且不被圖片遮擋
	5.	send 在（有文字 or 有圖片）時可點，顏色為 #4990BB，否則 disabled
	6.	按 send：若圖片存在 → 本機 OCR → 合併文字 → 走原本 parse 流程
	7.	OCR/截圖失敗時顯示 errorCard 並能 retry

⸻

11. Implementation Notes (給 Kiro 的工程提示)
	•	截圖 MVP：Process 執行 /usr/sbin/screencapture -i -x <path>
	•	完成後讀檔 NSImage(contentsOfFile:)
	•	OCR：Vision VNImageRequestHandler(cgImage:) + VNRecognizeTextRequest
	•	UI：InputView 的 textEditorCard 用 ZStack bottom 對齊，image preview 放在 toolbar 上方
	•	Keyboard：Esc cancel 截圖由 screencapture 本身處理即可